from sys import *
import os
installprompt = "cmd /c winget install "
print("""
________                           _____                        _________ __                        
\_____  \ ______   ____   ____    /  _  \ ______ ______  ______/   _____//  |_  ___________   ____  
 /   |   \\____ \_/ __ \ /    \  /  /_\  \\____ \\____ \/  ___/\_____  \\   __\/  _ \_  __ \_/ __ \ 
/    |    \  |_> >  ___/|   |  \/    |    \  |_> >  |_> >___ \ /        \|  | (  <_> )  | \/\  ___/ 
\_______  /   __/ \___  >___|  /\____|__  /   __/|   __/____  >_______  /|__|  \____/|__|    \___  >
        \/|__|        \/     \/         \/|__|   |__|       \/        \/                         \/

                                    --Made by NegativeNetwork--
                              --The app store for Windows FOSS apps!--
""")

print("""
Enter the app number to install it.
Applications available:
[C] Custom
[1] Firefox Browser
[2] Chromium
[3] Docker
[4] MS Skype
[5] MS Skype Insiders
[6] Discord
[7] Guilded
[8] HexChat
[9] Opera Stable
[10] Zoho Mail Desktop 
[11] Zoom Conferencing
[12] Zoom (Conferencing) Rooms
""")
while True:
    command = input("OAS> ")
    if command == "C":
        custominput = input("Type package name: ")
        custompackage = installprompt + custominput
        os.system(custompackage)
    if command == "1":
        os.system('cmd /c "winget install -e --id firefox"')
    if command == "2":
        os.system('cmd /c' "winget install -e --id Hibbiki.Chromium")
    if command == "3":
        os.system('cmd /c' "winget install -e --id Docker.DockerDesktop")
    if command == "4":
        os.system('cmd /c "winget install -e --id Microsoft.Skype"')
    if command == "5":
        os.system('cmd /c "winget install -e --id Microsoft.Skype.Insiders"')
    if command == "6":
        os.system('cmd /c "winget install -e --id Discord.Discord"')
    if command == "7":
        os.system('cmd /c "winget install -e --id Guilded.Guilded"')
    if command == "8":
        os.system('cmd /c "winget install -e --id HexChat.HexChat"')
    if command == "9":
        os.system('cmd /c "winget install -e --id Opera.Opera"')
    if command == "10":
        os.system('cmd /c "winget install -e --id Zoho.ZohoMail.Desktop"')
    if command == "11":
        os.system('cmd /c "winget install -e --id Zoom.Zoom"')
    if command == "12":
        os.system('cmd /c "winget install -e --id Zoom.ZoomRooms"')
    
    
